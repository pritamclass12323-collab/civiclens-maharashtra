CivicLens Maharashtra — updated prototype

How to open:
1. Extract the ZIP file.
2. Open index.html in a modern browser.

Updates:
- Added division dropdown for all six Maharashtra divisions.
- City / Town / Area dropdown changes dynamically based on the selected division.
- Location lists are based on the locations supplied by the project owner.
- Full address/locality field and the existing civic issue reporting UI are retained.

Important:
- This is still a front-end prototype. Reports are stored in this browser only if the existing localStorage logic is used.
- No shared database, live government integration, or secure moderator login has been added.
- The list contains a mix of cities, towns, and other settlements as supplied; administrative classification has not been independently verified.
